


<html>

<head>

<style>

table

{

border-style:solid;

border-width:4px;

border-color:black;

}

</style>

</head>

<body bgcolor="#EEEEFD">

<?php

$con = mysqli_connect("localhost","root","","hotel") or die(mysql_error());
 
 $result=mysqli_query($con,"SELECT * FROM roombook ");

 
echo "<table border='1'>

<tr>
	<th>Customer ID</th>
    <th>Name</th>
    <th>Email</th> 
	<th>Nationality</th> 
	<th>Country</th> 
	<th>Phone Number</th> 
	<th>Room Type</th> 
	<th>Number of Beds</th> 
	<th>Number of rooms</th> 
	<th>Preferred Meals</th> 
	<th>Check in date</th> 
	<th>Check out date</th> 
	<th>Booking Status</th> 
	<th>Number of days</th>

</tr>";

 

while($row = $result->fetch_assoc()) 

  {

  echo "<tr>";

  echo "<td>" . $row['id'] . "</td>";

  echo "<td>" . $row['Title'] .$row['FName']." ".$row['LName']."</td>";

  echo "<td>" . $row['Email'] . "</td>";

  echo "<td>" . $row['National'] . "</td>";

  echo "<td>" . $row['Country'] . "</td>";

  echo "<td>" . $row['Phone'] . "</td>";

  echo "<td>" . $row['TRoom'] . "</td>";

  echo "<td>" . $row['Bed'] . "</td>";

  echo "<td>" . $row['NRoom'] . "</td>";

  echo "<td>" . $row['Meal'] . "</td>";

  echo "<td>" . $row['cin'] . "</td>";

  echo "<td>" . $row['cout'] . "</td>";

  echo "<td>" . $row['stat'] . "</td>";

  echo "<td>" . $row['nodays'] . "</td>";

  echo "</tr>";

  }

echo "</table>";



?>
<a href="logout.php">Logout</a>
</body>

</html>
   